import React from "react";



export default function SearchBar() {

    return(
        <div>
            <h2>Search Bar</h2>
        </div>
    )
}